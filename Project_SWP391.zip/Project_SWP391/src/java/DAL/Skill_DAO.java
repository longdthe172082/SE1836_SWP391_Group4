/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAL;

import Model.Skill;
import com.sun.jdi.connect.spi.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author admin
 */
public class Skill_DAO extends DAL.DBContext{
    public static Skill_DAO INSTANCE = new Skill_DAO();
    private java.sql.Connection con;
    private String status = "OK";

    public Skill_DAO() {
        if (INSTANCE == null) {
            con = new DBContext().connection;
        } else {
            INSTANCE = this;
        }
    }

    public static Skill_DAO getInstance() {
        return INSTANCE;
    }
    
    public List<Skill> getAllSkills() {
    List<Skill> list = new ArrayList<>();
    String sql = "select SkillName,Image from Skill";
    try {
        PreparedStatement ps = connection.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            Skill skill = new Skill();
            skill.setSkillName(rs.getString("SkillName"));
            skill.setImage(rs.getString("Image"));
            list.add(skill);
        }
        ps.close();
        rs.close();
    } catch (Exception e) {
        e.printStackTrace();
    }
    return list;
}
    
    public static void main(String[] args) {
        Skill_DAO d = new Skill_DAO();
        List<Skill> l = d.getAllSkills();
        for (Skill skill : l) {
            System.out.println(skill);
        }
    }
}
