package DAL;

import Model.CV;
import Model.Mentor;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * CV Data Access Object
 */
public class CV_DAO {

    Connection conn = null;
    PreparedStatement ps = null;
    ResultSet rs = null;

    //close resources
    private void closeResources() {
        try {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (conn != null) {
                conn.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //view cv by mentor id
    public CV viewCVByMentorId(String mid) {
        String query = " select *\n"
                + "from CV \n"
                + "join Mentor on CV.MentorId = Mentor.MentorId\n"
                + "where Mentor.MentorId = ? ";

        try {
            // Open connection to SQL
            conn = new DBContext().connection;
            // Prepare SQL query
            ps = conn.prepareStatement(query);
            // Set the parameter value
            ps.setString(1, mid); // Set mentorid into the first placeholder
            // Execute query and get results
            rs = ps.executeQuery();

            if (rs.next()) {
                Mentor m = new Mentor(rs.getInt(1));
                //chuyen skill tu string sang array
                String[] skill = rs.getString(8).split(", ");
                return new CV(m,
                        rs.getString("FullName"),
                          rs.getString("AccName"),
                          rs.getString("Dob"),
                          rs.getString("PhoneNumber"),
                          rs.getString("Email"),
                          rs.getString("Avatar"),
                          skill, // Sử dụng mảng kỹ năng mới
                          rs.getString("Job"),
                          rs.getString("Job_Intro"),
                          rs.getString("Archivement"),
                          rs.getString("Service"),
                          rs.getString("Sex"),
                          rs.getString("Address"),
                          rs.getString("Framework"));
            } else {
                System.out.println("No CV found for Mentor ID: " + mid);
            }

        } catch (Exception e) {
            e.printStackTrace(); // Print exception details for debugging
        } finally {
            // Ensure resources are closed to prevent memory leaks
            closeResources();
        }

        return null;
    }

    //insert Mentor and return MentorId
    private int insertMentor(Mentor mentor) throws SQLException {
        //sql query
        String sql = "INSERT INTO [dbo].[Mentor]\n"
                + "           ([AccName]\n"
                + "           ,[Fullname]\n"
                + "           ,[PhoneNumber]\n"
                + "           ,[Email]\n"
                + "           ,[Avatar])\n"
                + "     VALUES\n"
                + "           (?,?,?,?,?) ";

        ps = conn.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
        ps.setString(1, mentor.getAccName()); //thiet lap tham so 1 cho AccName
        ps.setString(2, mentor.getFullName()); //thiet lap tham so 2 cho FullName
        ps.setString(3, mentor.getPhoneNumber());
        ps.setString(4, mentor.getEmail());
        ps.setString(5, mentor.getAvatar());

        //Thuc thi cau truy van chen Mentor vao co so du lieu
        ps.executeUpdate();

        //lay ket qua duoc sinh tu dong tu cau truy van
        rs = ps.getGeneratedKeys();

        if (rs.next()) {
            //Tra ve MentorId duoc sinh tu dong
            return rs.getInt(1);
        } else {
            throw new SQLException("Failed to insert mentor, no ID obtained.");
        }
    }

    //Insert CV
    private void insertCV(int mentorId, CV cv) throws SQLException {
        // Câu truy vấn để chèn CV vào bảng CV
        String sql = "INSERT INTO CV "
                + "(MentorId, AccName, FullName, Dob, PhoneNumber, Email, Avatar, Job, Job_Intro, Skill, [Service], Archivement, Sex, Address, Programming) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?)";

        //Tạo 1 PreparedStatement mới
        PreparedStatement psCV = conn.prepareStatement(sql);
        // Thiết lập các tham số cho câu truy vấn chèn CV
        psCV.setInt(1, mentorId);           // Thiết lập tham số cho MentorId
        psCV.setString(2, cv.getAccName()); // Thiết lập tham số cho AccName
        psCV.setString(3, cv.getFullName()); // Thiết lập tham số cho FullName
        psCV.setString(4, cv.getDob());     // Thiết lập tham số cho Dob
        psCV.setString(5, cv.getPhoneNumber()); // Thiết lập tham số cho PhoneNumber
        psCV.setString(6, cv.getEmail());    // Thiết lập tham số cho Email
        psCV.setString(7, cv.getAvatar());   // Thiết lập tham số cho Avatar
        psCV.setString(8, cv.getJob());      // Thiết lập tham số cho Job
        psCV.setString(9, cv.getJob_Intro());// Thiết lập tham số cho Job_Intro
        //chuyen skill from string to array
        String skill = String.join(", ", cv.getSkill());
        psCV.setString(10, skill);   // Thiết lập tham số cho Skill
        psCV.setString(11, cv.getService()); // Thiết lập tham số cho Service
        psCV.setString(12, cv.getArchivement()); // Thiết lập tham số cho Archivement
        psCV.setString(13, cv.getSex());
        psCV.setString(14, cv.getAddress());
        psCV.setString(15, cv.getFramework()); //framework: Programming
        psCV.executeUpdate(); // Thực thi câu truy vấn chèn CV vào cơ sở dữ liệu
    }

    public void createCV(Mentor mentor, CV cv) {

        try {

            conn = new DBContext().connection;
            conn.setAutoCommit(false);//tắt tự động giao dịch ??

            //chèn mentor vao cơ sở dữ liệu và lấy mentor
            int mentorId = insertMentor(mentor);

            //chèn CV vào cơ sở dữ liệu và lấy dữ lệu với MentorId tương ứng
            insertCV(mentorId, cv);

            //Kết thúc quá trình và lưu các thay đổi vào cơ sở dữ liệu
            conn.commit();

        } catch (Exception e) {
            e.printStackTrace();
        } //đóng kết nối
        finally {
            closeResources();

        }

    }

    public void createCVByMentorId(int mentorId, CV cv) {
        try {

            conn = new DBContext().connection;
            conn.setAutoCommit(false);

            //InsertCV từ MentorId
            insertCV(mentorId, cv);
            conn.commit();

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            closeResources();;
        }
    }

    //update cv by mentor id
    public void updateCVByMentorId(int mentorId, CV cv) throws SQLException {

        String sql = "UPDATE [dbo].[CV]\n"
                + "   SET \n"
                + "      [AccName] = ?\n"
                + "      ,[FullName] = ?\n"
                + "      ,[Dob] = ?\n"
                + "      ,[PhoneNumber] = ?\n"
                + "      ,[Email] = ?\n"
                + "      ,[Avatar] = ?\n"
                + "      ,[Job] = ?\n"
                + "      ,[Job_Intro] = ?\n"
                + "      ,[Skill] = ?\n"
                + "      ,[Service] = ?\n"
                + "      ,[Archivement] = ?\n"
                + "      ,[Sex] = ?\n"
                + "      ,[Address] = ?\n"
                + "      ,[Programming] = ?\n"
                + " WHERE MentorId = ?";

        try {

            conn = new DBContext().connection;

            ps = conn.prepareStatement(sql);

            // Thiết lập các tham số cho câu truy vấn
            ps.setString(1, cv.getAccName());
            ps.setString(2, cv.getFullName());
            ps.setString(3, cv.getDob());
            ps.setString(4, cv.getPhoneNumber());
            ps.setString(5, cv.getEmail());
            ps.setString(6, cv.getAvatar());
            ps.setString(7, cv.getJob());
            ps.setString(8, cv.getJob_Intro());
            //chuyen string to array
            String skill = String.join(",", cv.getSkill());
            ps.setString(9, skill);
            ps.setString(10, cv.getService());
            ps.setString(11, cv.getArchivement());
            ps.setString(12, cv.getSex());
            ps.setString(13, cv.getAddress());
            ps.setString(14, cv.getFramework());
            ps.setInt(15, mentorId);

            int row = ps.executeUpdate();

            if (row > 0) {
                System.out.println("CV updated succesfully for Mentor ID: " + mentorId);
            } else {
                System.out.println("No CV found for MentorID: " + mentorId);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources();
        }
    }
    
    public static void main(String[] args) {
        CV_DAO dao = new CV_DAO();
        int mentorId = 1;

        CV cv = new CV();
        cv.setAccName("LongDT2000");
        cv.setFullName("Doan Tuan Long");
        cv.setDob("26-10-2003");
        cv.setPhoneNumber("0833080988");
        cv.setEmail("longdthe172812@example.com");
        cv.setAvatar("avatar.jpg");
        cv.setJob("Software Engineer");
        cv.setJob_Intro("I am a passionate software engineer");
        cv.setSkill(new String[]{"Java", "SQL", "C"});
        cv.setService("Software development, Database design");
        cv.setArchivement("Completed multiple projects successfully.");
        cv.setSex("Male");
        cv.setAddress("Hoan Kiem-Ha Noi");
        cv.setFramework("Framework");

        try {
            CV existingCV = dao.viewCVByMentorId(String.valueOf(mentorId));
            if (existingCV != null) {
                dao.updateCVByMentorId(mentorId, cv);
                System.out.println("Update CV successful");
            } else {
                System.out.println("Mentor ID does not exist. Create CV failed!");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

//    public static void main(String[] args) {
//        CV_DAO dao = new CV_DAO();
//        int mentorId = 1;
//
//        CV cv = new CV();
//        cv.setAccName("LongDT2003");
//        cv.setFullName("Doan Tuan Long");
//        cv.setDob("26-10-2003");
//        cv.setPhoneNumber("0833080988");
//        cv.setEmail("longdthe172812@example.com");
//        cv.setAvatar("avatar.jpg");
//        cv.setJob("Software Engineer");
//        cv.setJob_Intro("I am a passionate software engineer");
//        cv.setSkill(new String[]{"Java, SQL, C"});
//        cv.setService("Software development, Database design");
//        cv.setArchivement("Completed multiple projects successfully.");
//        cv.setSex("Female");
//        cv.setAddress("Hoan Kiem-Ha Noi");
//        cv.setFramework("Framework");
//
//        try {
//            CV existingCV = dao.viewCVByMentorId(String.valueOf(mentorId));
//            if (existingCV != null) {
//                dao.updateCVByMentorId(mentorId, cv);
//                System.out.println("Update CV successful");
//            } else {
//                System.out.println("Mentor ID does not exist. Create CV failed!");
//            }
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//    }

//    public static void main(String[] args) {
//        CV_DAO dao = new CV_DAO();
//        int mentorId = 7;
//
//        CV cv = new CV();
//        cv.setAccName("LongDT2000");
//        cv.setFullName("Doan Tuan Long");
//        cv.setDob("26-10-2003");
//        cv.setPhoneNumber("0833080988");
//        cv.setEmail("longdthe172812");
//        cv.setAvatar("avatar.jpg");
//        cv.setJob("Software Engineer");
//        cv.setJob_Intro("I am a passionate software engineer");
//        cv.setSkill(new String[]{"Java, SQl, C"});
//        cv.setService("Software development, Database design");
//        cv.setArchivement("Completed multiple projects succesfully.");
//
//        
//
//        dao.createCVByMentorId(mentorId, cv);
//    }
//    public static void main(String[] args) {
//        CV_DAO cv = new CV_DAO();
//        String mid = "1";
//        CV cvd = cv.viewCVByMentorId(mid);
//
//        // Kiểm tra kết quả
//        if (cvd != null) {
//            System.out.println("Mentor CV retrieved successfully:");
//            System.out.println(cvd);
//        } else {
//            System.out.println("No CV found for Mentor ID: " + mid);
//        }
//    }
//    public static void main(String[] args) {
//
//        // Tạo một đối tượng CV_DAO
//        CV_DAO cvDao = new CV_DAO();
//        // Tạo một đối tượng Mentor
//        Mentor mentor = new Mentor();
//        mentor.setAccName("john_doe");
//        mentor.setFullName("John Doe");
//        mentor.setPhoneNumber("123456789");
//        mentor.setEmail("john.doe@example.com");
//        mentor.setAvatar("avatar.jpg");
//        // Giả sử có một đối tượng Account đã được tạo và được gán cho MentorId
//
//        // Tạo một đối tượng CV
//        CV cv = new CV();
//        cv.setAccName("john_doe");
//        cv.setFullName("John Doe");
//        cv.setDob("1990-01-01");
//        cv.setPhoneNumber("123456789");
//        cv.setEmail("john.doe@example.com");
//        cv.setAvatar("avatar.jpg");
//        cv.setJob("Software Engineer");
//        cv.setJob_Intro("I am a passionate software engineer.");
//        cv.setSkill("Java, Python, SQL");
//        cv.setService("Software development, Database design");
//        cv.setArchivement("Completed multiple projects successfully.");
//
//        // Gọi phương thức createCV để thêm Mentor và CV vào cơ sở dữ liệu
//        cvDao.createCV(mentor, cv);
//
//    }
}
