package DAL;

import Model.Mentor;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MentorDAO {

    private final Connection connection;

    public MentorDAO() {
        DBContext dbContext = new DBContext();
        this.connection = dbContext.connection;
    }
 public static void main(String[] args) {
        MentorDAO mentorDAO = new MentorDAO();
        List<Mentor> mentors = mentorDAO.getAllMentors();
        
        // Kiểm tra xem danh sách mentors có rỗng không
        if (mentors.isEmpty()) {
            System.out.println("Không có mentor nào được tìm thấy.");
        } else {
            System.out.println("Danh sách mentors:");
            for (Mentor mentor : mentors) {
                System.out.println(mentor);
            }
        }
    }
    public List<Mentor> getAllMentors() {
        List<Mentor> mentors = new ArrayList<>();
        String query = "SELECT * FROM Mentor";

        try (PreparedStatement statement = connection.prepareStatement(query);
             ResultSet rs = statement.executeQuery()) {
            while (rs.next()) {
                int MentorId = rs.getInt("MentorId");
                String AccName = rs.getString("AccName");
                String FullName = rs.getString("FullName");
                String PhoneNumber = rs.getString("PhoneNumber");
                String Email = rs.getString("Email");
                String Avatar = rs.getString("Avatar");
                // Tạo đối tượng Mentor và thêm vào danh sách
                Mentor mentor = new Mentor(MentorId, FullName, AccName, PhoneNumber, Email,Avatar);
                mentors.add(mentor);
            }
        } catch (SQLException e) {
            // Xử lý ngoại lệ SQL ở đây
            e.printStackTrace();
        }

        return mentors;
    }
}
